package com.nextneo.launcher

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppInfo(
    val key: String,
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

const val MAX_DOCK = 4

val EFFECTS = listOf("Cubo", "Carrusel", "Abanico", "Voltear", "Profundidad")

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private val launcherApps = app.getSystemService(LauncherApps::class.java)
    private val me: UserHandle = Process.myUserHandle()

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set
    var dock by mutableStateOf(readList("dock"))
        private set
    var pinned by mutableStateOf(readList("pinned"))
        private set

    val dockFull: Boolean get() = dock.size >= MAX_DOCK

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) { refresh() }
        override fun onPackageAdded(packageName: String, user: UserHandle) { refresh() }
        override fun onPackageChanged(packageName: String, user: UserHandle) { refresh() }
        override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) { refresh() }
        override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) { refresh() }
    }

    init {
        launcherApps.registerCallback(callback)
        refresh()
    }

    override fun onCleared() {
        launcherApps.unregisterCallback(callback)
    }

    fun refresh() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.Default) { load() }
            apps = list
            applyDefaultsOnce(list)
        }
    }

    private fun load(): List<AppInfo> {
        val self = getApplication<Application>().packageName
        return launcherApps.getActivityList(null, me)
            .filter { it.componentName.packageName != self }
            .map {
                AppInfo(
                    key = it.componentName.flattenToString(),
                    label = it.label.toString(),
                    pkg = it.componentName.packageName,
                    component = it.componentName,
                    icon = it.getBadgedIcon(0).toBitmap(144, 144).asImageBitmap(),
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun applyDefaultsOnce(list: List<AppInfo>) {
        if (list.isEmpty() || prefs.contains("dock")) return
        val pm = getApplication<Application>().packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        )
        val keys = intents
            .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .mapNotNull { p -> list.firstOrNull { it.pkg == p }?.key }
            .distinct()
            .take(MAX_DOCK)
        dock = keys
        save("dock", keys)
    }

    fun toggleDock(a: AppInfo) {
        dock = when {
            a.key in dock -> dock - a.key
            dock.size < MAX_DOCK -> dock + a.key
            else -> dock
        }
        save("dock", dock)
    }

    var effect by mutableStateOf(prefs.getInt("effect", 0).coerceIn(0, EFFECTS.size - 1))
        private set

    fun chooseEffect(i: Int) {
        effect = i.coerceIn(0, EFFECTS.size - 1)
        prefs.edit().putInt("effect", effect).apply()
    }

    private fun moved(list: List<String>, fromKey: String, toKey: String): List<String> {
        val m = list.toMutableList()
        val f = m.indexOf(fromKey)
        val t = m.indexOf(toKey)
        if (f < 0 || t < 0 || f == t) return list
        val item = m.removeAt(f)
        m.add(t, item)
        return m
    }

    fun movePinned(fromKey: String, toKey: String) {
        pinned = moved(pinned, fromKey, toKey)
        save("pinned", pinned)
    }

    fun moveDock(fromKey: String, toKey: String) {
        dock = moved(dock, fromKey, toKey)
        save("dock", dock)
    }

    fun togglePinned(a: AppInfo) {
        pinned = if (a.key in pinned) pinned - a.key else pinned + a.key
        save("pinned", pinned)
    }

    fun launch(a: AppInfo) {
        try {
            launcherApps.startMainActivity(a.component, me, null, null)
        } catch (e: Exception) {
            val ctx = getApplication<Application>()
            ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(it)
            }
        }
    }

    fun details(a: AppInfo) {
        try {
            launcherApps.startAppDetailsActivity(a.component, me, null, null)
        } catch (_: Exception) {
        }
    }

    private fun readList(k: String): List<String> =
        (prefs.getString(k, "") ?: "").split("|").filter { it.isNotBlank() }

    private fun save(k: String, v: List<String>) {
        prefs.edit().putString(k, v.joinToString("|")).apply()
    }
}
