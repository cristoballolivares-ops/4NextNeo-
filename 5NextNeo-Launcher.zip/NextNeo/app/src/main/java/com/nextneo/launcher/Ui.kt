package com.nextneo.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.roundToInt

val Neon = Color(0xFF38D6FF)
private val Ink = Color(0xFF050B1A)

@Composable
fun NeonTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Neon, surface = Color(0xFF0B1730)), content = content)
}

@Composable
fun LauncherScreen(vm: LauncherViewModel, homeSignal: Int) {
    var drawerOpen by remember { mutableStateOf(false) }
    val byKey = remember(vm.apps) { vm.apps.associateBy { it.key } }
    val pinnedApps = vm.pinned.mapNotNull { byKey[it] }
    val dockApps = vm.dock.mapNotNull { byKey[it] }

    val pages: List<List<AppInfo>> = remember(pinnedApps) {
        val all = listOf(pinnedApps.take(8)) + pinnedApps.drop(8).chunked(16)
        if (all.size < 2) all + listOf(emptyList()) else all
    }
    val pagerState = rememberPagerState { pages.size }

    LaunchedEffect(homeSignal) {
        drawerOpen = false
        pagerState.animateScrollToPage(0)
    }
    BackHandler(enabled = drawerOpen) { drawerOpen = false }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -90f && !drawerOpen) drawerOpen = true },
                    onDragCancel = { },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0x66000814), Color.Transparent, Color(0xAA000814)))),
        )
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            HorizontalPager(pagerState, Modifier.weight(1f)) { page ->
                CubePage(pagerState, page, vm.effect) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                        if (page == 0) ClockHeader(vm)
                        val apps = pages[page]
                        if (apps.isEmpty()) {
                            Text(
                                "Mantén pulsada una app en el cajón para anclarla aquí",
                                color = Color(0x99FFFFFF),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 24.dp, end = 24.dp),
                            )
                        } else {
                            BoxWithConstraints(Modifier.fillMaxWidth()) {
                                ReorderGrid(
                                    apps = apps,
                                    columns = 4,
                                    cellWidth = maxWidth / 4,
                                    cellHeight = 92.dp,
                                    showLabel = true,
                                    onMove = { f, t -> vm.movePinned(f, t) },
                                    onClick = { vm.launch(it) },
                                    menu = { app, dismiss -> AppMenu(vm, app, dismiss) },
                                )
                            }
                        }
                    }
                }
            }
            PageIndicator(pages.size, pagerState.currentPage)
            Dock(dockApps, vm, onOpenDrawer = { drawerOpen = true })
        }

        AnimatedVisibility(
            visible = drawerOpen,
            enter = fadeIn() + slideInVertically { it / 6 },
            exit = fadeOut() + slideOutVertically { it / 6 },
        ) {
            AppDrawer(vm, onClose = { drawerOpen = false })
        }
    }
}

@Composable
private fun CubePage(state: PagerState, page: Int, effect: Int, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val pos = (page - state.currentPage) - state.currentPageOffsetFraction
                val p = pos.coerceIn(-1f, 1f)
                val a = abs(p)
                cameraDistance = 16f * density
                when (effect) {
                    1 -> { // Carrusel
                        transformOrigin = TransformOrigin.Center
                        rotationY = -55f * p
                        translationX = -p * size.width * 0.22f
                        scaleX = 1f - 0.2f * a
                        scaleY = 1f - 0.2f * a
                        alpha = 1f - 0.6f * a
                    }
                    2 -> { // Abanico
                        transformOrigin = TransformOrigin(0.5f, 1.4f)
                        rotationZ = 28f * p
                        translationX = -p * size.width * 0.5f
                        alpha = 1f - 0.5f * a
                    }
                    3 -> { // Voltear
                        transformOrigin = TransformOrigin.Center
                        rotationY = -180f * p
                        translationX = -p * size.width
                        alpha = if (a < 0.5f) 1f else 0f
                    }
                    4 -> { // Profundidad
                        transformOrigin = TransformOrigin.Center
                        rotationY = -20f * p
                        translationX = -p * size.width * 0.5f
                        scaleX = 1f - 0.25f * a
                        scaleY = 1f - 0.25f * a
                        alpha = 1f - 0.8f * a
                    }
                    else -> { // Cubo
                        transformOrigin = TransformOrigin(if (pos < 0f) 1f else 0f, 0.5f)
                        rotationY = -90f * p
                        alpha = if (abs(pos) >= 1f) 0f else 1f - 0.5f * a
                    }
                }
            },
        content = content,
    )
}

@Composable
private fun ClockHeader(vm: LauncherViewModel) {
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val timeFmt = remember { DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT) }
    val dateFmt = remember { DateTimeFormatter.ofPattern("EEEE d MMM", Locale.getDefault()) }
    Box(Modifier.fillMaxWidth()) {
    Column(Modifier.fillMaxWidth().padding(top = 36.dp, bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            now.format(timeFmt),
            color = Color.White,
            fontSize = 76.sp,
            fontWeight = FontWeight.ExtraLight,
            style = TextStyle(shadow = Shadow(Neon.copy(alpha = 0.7f), Offset.Zero, 28f)),
        )
        Text(
            now.format(dateFmt).replaceFirstChar { it.uppercase() },
            color = Color(0xCCFFFFFF),
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
        )
    }
    EffectPicker(vm, Modifier.align(Alignment.TopEnd).padding(top = 6.dp))
    }
}

@Composable
private fun EffectPicker(vm: LauncherViewModel, modifier: Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Text(
            "3D · ${EFFECTS[vm.effect]} ▾",
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0x2238D6FF))
                .border(1.dp, Neon.copy(alpha = 0.5f), CircleShape)
                .clickable { open = true }
                .padding(horizontal = 12.dp, vertical = 6.dp),
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            EFFECTS.forEachIndexed { i, name ->
                DropdownMenuItem(text = { Text(name) }, onClick = { vm.chooseEffect(i); open = false })
            }
        }
    }
}

@Composable
private fun GlossIcon(app: AppInfo, reflection: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(56.dp)) {
            for (i in 4 downTo 1) {
                Image(
                    bitmap = app.icon,
                    contentDescription = null,
                    modifier = Modifier.matchParentSize().offset((i * 0.8f).dp, (i * 1.0f).dp),
                    colorFilter = ColorFilter.tint(Color(0xCC061826), BlendMode.SrcIn),
                )
            }
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.matchParentSize())
            Box(
                Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(colorStops = arrayOf(0f to Color(0x40FFFFFF), 0.5f to Color.Transparent))),
            )
        }
        if (reflection) {
            Canvas(
                Modifier
                    .size(56.dp, 14.dp)
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen },
            ) {
                val s = size.width
                clipRect(0f, 0f, s, size.height) {
                    scale(1f, -1f, pivot = Offset(s / 2f, s / 2f)) {
                        drawImage(app.icon, dstSize = IntSize(s.roundToInt(), s.roundToInt()), alpha = 0.38f)
                    }
                }
                drawRect(Brush.verticalGradient(listOf(Color.Black, Color.Transparent)), blendMode = BlendMode.DstIn)
            }
        }
    }
}

@Composable
private fun ReorderGrid(
    apps: List<AppInfo>,
    columns: Int,
    cellWidth: Dp,
    cellHeight: Dp,
    showLabel: Boolean,
    onMove: (String, String) -> Unit,
    onClick: (AppInfo) -> Unit,
    menu: @Composable (AppInfo, () -> Unit) -> Unit,
) {
    val density = LocalDensity.current
    val cw = with(density) { cellWidth.roundToPx() }
    val ch = with(density) { cellHeight.roundToPx() }
    val rows = (apps.size + columns - 1) / columns
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    val from = apps.indexOfFirst { it.key == dragKey }
    val hover = if (from < 0) -1 else {
        val cx = (from % columns) * cw + cw / 2f + dragOffset.x
        val cy = (from / columns) * ch + ch / 2f + dragOffset.y
        val col = (cx / cw).toInt().coerceIn(0, columns - 1)
        val row = (cy / ch).toInt().coerceIn(0, rows - 1)
        (row * columns + col).coerceIn(0, apps.size - 1)
    }
    Box(Modifier.width(cellWidth * columns).height(cellHeight * rows)) {
        apps.forEachIndexed { i, app ->
            key(app.key) {
                val isDragged = i == from
                val shown = when {
                    from < 0 || isDragged -> i
                    from < hover && i > from && i <= hover -> i - 1
                    from > hover && i >= hover && i < from -> i + 1
                    else -> i
                }
                val target = IntOffset((shown % columns) * cw, (shown / columns) * ch)
                val dragPos = IntOffset(
                    (from % columns) * cw + dragOffset.x.roundToInt(),
                    (from / columns) * ch + dragOffset.y.roundToInt(),
                )
                val anim = remember { Animatable(target, IntOffset.VectorConverter) }
                LaunchedEffect(isDragged, if (isDragged) dragPos else target) {
                    if (isDragged) anim.snapTo(dragPos) else anim.animateTo(target)
                }
                Box(
                    Modifier
                        .offset { if (isDragged) dragPos else anim.value }
                        .size(cellWidth, cellHeight)
                        .zIndex(if (isDragged) 1f else 0f)
                        .graphicsLayer {
                            if (isDragged) {
                                scaleX = 1.15f
                                scaleY = 1.15f
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    DraggableAppIcon(
                        app = app,
                        showLabel = showLabel,
                        onClick = { onClick(app) },
                        onDragStart = { dragKey = app.key; dragOffset = Offset.Zero },
                        onDrag = { dragOffset = it },
                        onDragEnd = {
                            if (from >= 0 && hover >= 0 && hover != from) onMove(app.key, apps[hover].key)
                            dragKey = null
                            dragOffset = Offset.Zero
                        },
                        menu = { dismiss -> menu(app, dismiss) },
                    )
                }
            }
        }
    }
}

@Composable
private fun DraggableAppIcon(
    app: AppInfo,
    showLabel: Boolean,
    onClick: () -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    menu: @Composable (dismiss: () -> Unit) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    var active by remember { mutableStateOf(false) }
    var lastEnd by remember { mutableLongStateOf(0L) }
    var total by remember { mutableStateOf(Offset.Zero) }
    val haptic = LocalHapticFeedback.current
    val clickCb by rememberUpdatedState(onClick)
    val startCb by rememberUpdatedState(onDragStart)
    val dragCb by rememberUpdatedState(onDrag)
    val endCb by rememberUpdatedState(onDragEnd)
    Box {
        Column(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .clickable {
                    if (!active && System.currentTimeMillis() - lastEnd > 300L) clickCb()
                }
                .pointerInput(Unit) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = {
                            active = true
                            total = Offset.Zero
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            startCb()
                        },
                        onDrag = { change, amount ->
                            change.consume()
                            total += amount
                            dragCb(total)
                        },
                        onDragEnd = {
                            active = false
                            lastEnd = System.currentTimeMillis()
                            val tap = total.getDistance() < 16f
                            endCb()
                            if (tap) expanded = true
                        },
                        onDragCancel = {
                            active = false
                            lastEnd = System.currentTimeMillis()
                            endCb()
                        },
                    )
                }
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            GlossIcon(app, reflection = !showLabel)
            if (showLabel) {
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(68.dp).padding(top = 4.dp),
                    textAlign = TextAlign.Center,
                    style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 6f)),
                )
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            menu { expanded = false }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppIcon(
    app: AppInfo,
    showLabel: Boolean = true,
    onClick: () -> Unit,
    menu: @Composable (dismiss: () -> Unit) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    Box {
        Column(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        expanded = true
                    },
                )
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            GlossIcon(app, reflection = !showLabel)
            if (showLabel) {
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(68.dp).padding(top = 4.dp),
                    textAlign = TextAlign.Center,
                    style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 6f)),
                )
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            menu { expanded = false }
        }
    }
}

@Composable
private fun AppMenu(vm: LauncherViewModel, app: AppInfo, dismiss: () -> Unit) {
    val pinned = app.key in vm.pinned
    val inDock = app.key in vm.dock
    DropdownMenuItem(
        text = { Text(if (pinned) "Quitar del inicio" else "Anclar al inicio") },
        onClick = { vm.togglePinned(app); dismiss() },
    )
    DropdownMenuItem(
        text = { Text(if (inDock) "Quitar del dock" else if (vm.dockFull) "Dock lleno" else "Añadir al dock") },
        enabled = inDock || !vm.dockFull,
        onClick = { vm.toggleDock(app); dismiss() },
    )
    DropdownMenuItem(
        text = { Text("Información de la app") },
        onClick = { vm.details(app); dismiss() },
    )
}

@Composable
private fun PageIndicator(count: Int, current: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
        repeat(count) { i ->
            val selected = i == current
            val w by animateDpAsState(if (selected) 22.dp else 7.dp, label = "indicator")
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .height(7.dp)
                    .width(w)
                    .then(if (selected) Modifier.shadow(10.dp, CircleShape, ambientColor = Neon, spotColor = Neon) else Modifier)
                    .clip(CircleShape)
                    .background(if (selected) Neon else Color(0x55FFFFFF)),
            )
        }
    }
}

@Composable
private fun Dock(apps: List<AppInfo>, vm: LauncherViewModel, onOpenDrawer: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    BoxWithConstraints(
        Modifier
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x14FFFFFF))))
            .border(1.dp, Brush.verticalGradient(listOf(Color(0x77FFFFFF), Color(0x2038D6FF))), shape),
    ) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val top = h * 0.74f
            val inset = w * 0.05f
            val shelf = Path().apply {
                moveTo(inset, top)
                lineTo(w - inset, top)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(shelf, Brush.verticalGradient(listOf(Neon.copy(alpha = 0.30f), Color(0x10FFFFFF)), startY = top, endY = h))
            drawLine(Neon.copy(alpha = 0.8f), Offset(inset, top), Offset(w - inset, top), strokeWidth = 3f)
        }
        val slots = apps.size + 1
        val slotW = maxWidth / slots
        Box(Modifier.fillMaxWidth().height(84.dp)) {
            ReorderGrid(
                apps = apps,
                columns = slots,
                cellWidth = slotW,
                cellHeight = 84.dp,
                showLabel = false,
                onMove = { f, t -> vm.moveDock(f, t) },
                onClick = { vm.launch(it) },
                menu = { app, dismiss -> AppMenu(vm, app, dismiss) },
            )
            Box(
                Modifier.offset(x = slotW * apps.size).size(slotW, 84.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color(0x2238D6FF))
                        .border(1.dp, Neon.copy(alpha = 0.6f), CircleShape)
                        .clickable(onClick = onOpenDrawer),
                    contentAlignment = Alignment.Center,
                ) {
                    SpinningCube(Modifier.size(38.dp))
                }
            }
        }
    }
}

@Composable
private fun AppDrawer(vm: LauncherViewModel, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(vm.apps, query) {
        if (query.isBlank()) vm.apps else vm.apps.filter { it.label.contains(query, ignoreCase = true) }
    }
    val pages = remember(filtered) { filtered.chunked(20) }
    val state = rememberPagerState { pages.size.coerceAtLeast(1) }
    LaunchedEffect(query) { state.scrollToPage(0) }
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xF2050B1A), Color(0xF7081A33))))
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 16.dp),
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 12.dp)
                .size(44.dp, 5.dp)
                .clip(CircleShape)
                .background(Color(0x66FFFFFF))
                .clickable(onClick = onClose),
        )
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Neon),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            decorationBox = { inner ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x1FFFFFFF))
                        .border(1.dp, Color(0x2238D6FF), RoundedCornerShape(24.dp))
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                ) {
                    if (query.isEmpty()) Text("Buscar apps", color = Color(0x99FFFFFF))
                    inner()
                }
            },
        )
        HorizontalPager(state, Modifier.weight(1f)) { page ->
            CubePage(state, page, vm.effect) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val cellH = maxHeight / 5
                    Column(Modifier.fillMaxSize()) {
                        pages.getOrElse(page) { emptyList() }.chunked(4).forEach { row ->
                            Row(Modifier.fillMaxWidth().height(cellH)) {
                                row.forEach { app ->
                                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                                        AppIcon(app, onClick = { vm.launch(app); onClose() }) { dismiss -> AppMenu(vm, app, dismiss) }
                                    }
                                }
                                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
        }
        PageIndicator(pages.size, state.currentPage)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SpinningCube(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "cube")
    val yaw by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "yaw",
    )
    Canvas(modifier) {
        val a = Math.toRadians(yaw.toDouble()).toFloat()
        val b = 0.55f
        val ca = cos(a); val sa = sin(a); val cb = cos(b); val sb = sin(b)
        fun rot(x: Float, y: Float, z: Float): FloatArray {
            val x1 = x * ca + z * sa
            val z1 = -x * sa + z * ca
            val y2 = y * cb - z1 * sb
            val z2 = y * sb + z1 * cb
            return floatArrayOf(x1, y2, z2)
        }
        val dist = 5f
        val unit = size.minDimension / 3.2f
        val c = Offset(size.width / 2f, size.height / 2f)
        fun proj(p: FloatArray): Offset {
            val k = dist / (dist - p[2])
            return Offset(c.x + p[0] * k * unit, c.y + p[1] * k * unit)
        }
        val ll = sqrt(0.4f * 0.4f + 0.6f * 0.6f + 0.7f * 0.7f)
        val light = floatArrayOf(-0.4f / ll, -0.6f / ll, 0.7f / ll)

        class Face(val depth: Float, val path: Path, val shade: Float)
        val faces = ArrayList<Face>()
        for (axis in 0..2) for (sign in intArrayOf(-1, 1)) {
            val i = (axis + 1) % 3
            val j = (axis + 2) % 3
            val n = FloatArray(3).also { it[axis] = sign.toFloat() }
            val nr = rot(n[0], n[1], n[2])
            if (nr[2] * dist - 1f <= 0f) continue
            val path = Path()
            val corners = arrayOf(-1f to -1f, 1f to -1f, 1f to 1f, -1f to 1f)
            var zsum = 0f
            corners.forEachIndexed { idx, (u, v) ->
                val q = FloatArray(3)
                q[axis] = sign.toFloat(); q[i] = u; q[j] = v
                val r = rot(q[0], q[1], q[2])
                zsum += r[2]
                val o = proj(r)
                if (idx == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
            }
            path.close()
            val shade = (nr[0] * light[0] + nr[1] * light[1] + nr[2] * light[2]).coerceIn(0f, 1f)
            faces.add(Face(zsum / 4f, path, shade))
        }
        faces.sortBy { it.depth }
        for (f in faces) {
            drawPath(f.path, lerp(Color(0xFF0B3050), Neon, 0.25f + 0.75f * f.shade).copy(alpha = 0.9f))
            drawPath(f.path, Color.White.copy(alpha = 0.85f), style = Stroke(width = 2f))
        }
    }
}
